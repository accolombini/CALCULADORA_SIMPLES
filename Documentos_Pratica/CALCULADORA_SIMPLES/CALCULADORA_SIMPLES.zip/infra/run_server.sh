#!/bin/bash
docker-compose -f infra/docker-compose.yml up
